import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Arrays;






public class SocketThread extends Thread{
	static String EOL = "@end>";
	Socket sock;
	String UserID;
	public SocketThread(){
		this.sock=null;
		this.UserID="";
	}
	public SocketThread(Socket _sock){
		this.sock=_sock;
	}
	@Override
	public void run() {
		
		try {
			BufferedReader bReader=new BufferedReader(new InputStreamReader(sock.getInputStream()));
			BufferedWriter bWriter=new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
			
			InputStream ins = sock.getInputStream();
			OutputStream outs = sock.getOutputStream();
			
			//Read Instruction
			String inst = "";
			byte[] instBuffer = new byte[150];
			int bytesRead = 0,offset=0;
			do{
				bytesRead = ins.read(instBuffer,offset,instBuffer.length-1-offset);
				offset+=bytesRead;
				inst+=new String(instBuffer);
				
				if(checkEOL(instBuffer,offset))
					break;
			}while(bytesRead>=1);
			inst = inst.trim();
			inst = inst.substring(0, inst.length()-EOL.length());
			System.out.println("instruction Read:"+inst);
			String OwnerID = getOwnerID(inst);
			
			switch (parseInstruction(inst)) {
			case 1:
				bWriter.write(UploadedFiles.getNumOfFiles(OwnerID)+"\n");bWriter.flush();
				break;
			case 2:
				bWriter.write(new String(UploadedFiles.getRecord(OwnerID))+"\n");bWriter.flush();
				UploadedFiles.deleteRecord(OwnerID);
				break;
			case 3:
				char[] cbuf=new char[getSize(inst)];
				bReader.read(cbuf);
				String raw_data = new String(cbuf);
				byte[] raw_bytes = raw_data.getBytes();
				server.files.saveRecord(OwnerID, raw_bytes);
				bWriter.write("SUCCESS"+"\n");bWriter.flush();
				break;
			case 4:
				//Read image and return back..
				{
					int size = Integer.parseInt(inst.split("<:>")[1]);
					byte[] buffer = new byte[size];
					int readCount = 0,buffer_offset=0;
					do{
						readCount = ins.read(buffer,buffer_offset,buffer.length-1-buffer_offset);
						buffer_offset+=readCount;
						
						if(checkEOL(buffer,buffer_offset))
							break;
					}while(readCount>=1);
					
					outs.write(buffer);outs.flush();
				}
			default:
				break;
			}
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				sock.close();
				System.out.println("Closing connection");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	private int parseInstruction(String inst){
		int instType=0;
		
		String[] tokens=inst.split("<:>");
		if(tokens.length==2){
			if(tokens[0].equals("GET")){
				instType=1;
			}else if(tokens[0].equals("PING")){
				instType=4;
			}
		}else if(tokens.length==3||tokens.length==4){
			if(tokens[0].equals("GET")){
				instType=2;
			}else if(tokens[0].equals("SEND")){
				instType=3;
			}
		}
		
		return instType;
	}
	
	private String getOwnerID(String inst){
		String[] tokens=inst.split("<:>");

		switch (parseInstruction(inst)) {
		case 1:
			
		case 2:
			if(tokens[1]!=null){
				return tokens[1];
			}else{
				return null;
			}
		case 3:
			if(tokens[2]!=null){
				return tokens[2];
			}else{
				return null;
			}
	
			
			
		default:
			return null;
		}
	}
	
	private int getSize(String inst){
		String[] tokens=inst.split("<:>");
		int size=0;
		try{
			size=Integer.parseInt(tokens[3]);
		}catch(Exception e){
			
		}finally{
			
		}
		
		return size;
	}
	
	private boolean checkEOL(byte[] data,int dataLen){
		boolean containsEOL = false;
		
		try{
			int len = dataLen;
			if(data[len-1]==62){
				if(data[len-2]==100){
					if(data[len-3]==110){
						if(data[len-4]==101){
							if(data[len-5]==64){
								containsEOL = true;
							}	
						}	
					}	
				}
			}
		}catch(Exception e){
			
		}
		
		return containsEOL;
	}
}
